<section class="panel">
	<div class="tabs-custom">
		<ul class="nav nav-tabs">
			<li class="active">
				<a href="<?= base_url('colleges') ?>"><i class="fas fa-graduation-cap"></i>Medical College</a>
			</li>
			<?php if (get_permission('section', 'is_view')) : ?>
			
			<?php endif; ?>
		</ul>
		<div class="tab-content">
			<div class="tab-pane active">
				<div class="row">
					<?php if (get_permission('classes', 'is_add')) : ?>
						<div class="col-md-5 pr-xs">
							<section class="panel panel-custom">
								<div class="panel-heading panel-heading-custom">
									<h4 class="panel-title"><i class="far fa-edit"></i> Create Medical College</h4>
								</div>
								<?php echo form_open($this->uri->uri_string(), array('class' => 'frm-submit')); ?>
								<div class="panel-body panel-body-custom">
									
									<div class="form-group">
										<label class="control-label"><?= translate('name') ?> <span class="required">*</span></label>
										<input type="text" class="form-control" name="name" value="" />
										<span class="error"></span>
									</div>
									<div class="form-group">
										<label class="control-label">Numeric</label>
										<input type="text" class="form-control" name="name_numeric" value="" />
										<span class="error"></span>
									</div>
									
								</div>
								<footer class="panel-footer panel-footer-custom">
									<div class="text-right">
										<button type="submit" class="btn btn-default" data-loading-text="<i class='fas fa-spinner fa-spin'></i> Processing">
											<i class="fas fa-plus-circle"></i> <?= translate('save') ?>
										</button>
									</div>
								</footer>
								<?php echo form_close(); ?>
							</section>
						</div>
					<?php endif; ?>
					<div class="col-md-<?php if (get_permission('classes', 'is_add')) {
											echo "7 pl-xs";
										} else {
											echo "12";
										} ?>">
						<section class="panel panel-custom">
							<header class="panel-heading panel-heading-custom">
								<h4 class="panel-title"><i class="fas fa-list-ul"></i> Medical College</h4>
							</header>
							<div class="panel-body panel-body-custom">
								<div class="table-responsive">
									<table class="table table-bordered table-hover table-condensed tbr-top mb-none">
										<thead>
											<tr>
												<th>#</th>

												<th>Medical College</th>
												<th>Numeric</th>
												<th><?= translate('action') ?></th>
											</tr>
										</thead>
										<tbody>
											<?php
											$count = 1;
											if (count($collegelist)) {
												foreach ($collegelist as $row) :
											?>
													<tr>
														<td><?php echo $count++; ?></td>

														<td><?php echo $row['name']; ?></td>

														<td><?php echo $row['name_numeric']; ?></td>
														<td>
															<?php if (get_permission('classes', 'is_edit')) : ?>
																<!--update link-->
																<a href="<?php echo base_url('colleges/edit/' . $row['id']); ?>" class="btn btn-default btn-circle icon">
																	<i class="fas fa-pen-nib"></i>
																</a>
															<?php endif;
															if (get_permission('colleges', 'is_delete')) : ?>
																<!--delete link-->
																<?php echo btn_delete('colleges/delete/' . $row['id']); ?>
															<?php endif; ?>
														</td>
													</tr>
											<?php
												endforeach;
											} else {
												echo '<tr><td colspan="6"><h5 class="text-danger text-center">' . translate('no_information_available') . '</td></tr>';
											}
											?>
										</tbody>
									</table>
								</div>
							</div>
						</section>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>