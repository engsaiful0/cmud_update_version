<section class="panel">
	<div class="tabs-custom">
		<ul class="nav nav-tabs">
			<li class="active">
				<a href="#list" data-toggle="tab"><i class="fas fa-list-ul"></i> <?= translate('course_list') ?></a>
			</li>
			<?php if (get_permission('subject', 'is_add')) : ?>
				<li>
					<a href="#create" data-toggle="tab"><i class="far fa-edit"></i> <?= translate('create_course') ?></a>
				</li>
			<?php endif; ?>
		</ul>
		<div class="tab-content">
			<div id="list" class="tab-pane active">
				<table class="table table-bordered table-hover mb-none table-export">
					<thead>
						<tr>
							<th width="60"><?= translate('sl') ?></th>
							<th><?= translate('branch') ?></th>
							<th><?= translate('course_name') ?></th>
							<th>Fee</th>
							<th><?= translate('course_code') ?></th>
							<th><?= translate('course_type') ?></th>
							<th><?= translate('duration') ?></th>
							<th><?= translate('course_author') ?></th>
							<th><?= translate('action') ?></th>
						</tr>
					</thead>
					<tbody>
						<?php
						$count = 1;
						foreach ($subjectlist as $row) :
						?>
							<tr>
								<td><?php echo $count++; ?></td>
								<td><?php echo $row['branch_name']; ?></td>
								<td><?php echo $row['name']; ?></td>
								<td><?php echo $row['fee']; ?></td>
								<td><?php echo $row['subject_code']; ?></td>
								<td><?php echo $row['subject_type']; ?></td>
								<td><?php echo $row['course_duration'].' '.$row['course_duration_years_month_day']; ?></td>
								<td><?php echo $row['subject_author']; ?></td>
								<td>
									<?php if (get_permission('subject', 'is_edit')) : ?>
										<!-- subject update link -->
										<a href="<?php echo base_url('subject/edit/' . $row['id']); ?>" class="btn btn-circle btn-default icon">
											<i class="fas fa-pen-nib"></i>
										</a>
									<?php endif;
									if (get_permission('subject', 'is_delete')) : ?>
										<!-- delete link -->
										<?php echo btn_delete('subject/delete/' . $row['id']); ?>
									<?php endif; ?>
								</td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			</div>
			<?php if (get_permission('subject', 'is_add')) : ?>
				<div class="tab-pane" id="create">
					<?php echo form_open('subject/save', array('class' => 'form-horizontal form-bordered frm-submit')); ?>
					<?php if (is_superadmin_loggedin()) : ?>
						<div class="form-group">
							<label class="control-label col-md-3"><?= translate('branch') ?> <span class="required">*</span></label>
							<div class="col-md-6">
								<?php
								$arrayBranch = $this->app_lib->getSelectList('branch');
								echo form_dropdown("branch_id", $arrayBranch, set_value('branch_id'), "class='form-control' data-width='100%'
									data-plugin-selectTwo  data-minimum-results-for-search='Infinity'");
								?>
								<span class="error"></span>
							</div>
						</div>
					<?php endif; ?>
					<div class="form-group">
						<label class="col-md-3 control-label"><?= translate('course_name') ?> <span class="required">*</span></label>
						<div class="col-md-6">
							<input type="text" class="form-control" name="name" />
							<span class="error"></span>
						</div>
					</div>
					<div class="form-group">
						<label class="col-md-3 control-label">Fee <span class="required">*</span></label>
						<div class="col-md-6">
							<input required type="number" id="fee" class="form-control" name="fee" />
							<span class="error"></span>
						</div>
					</div>
					<div class="form-group">
						<label class="col-md-3 control-label"><?= translate('course_code') ?> <span class="required">*</span></label>
						<div class="col-md-6">
							<input type="text" class="form-control" name="subject_code" />
							<span class="error"></span>
						</div>
					</div>
					<div class="form-group">
						<label class="col-md-3 control-label"><?= translate('course_duration') ?> <span class="required">*</span></label>
						<div class="col-md-3">
							<input type="number" class="form-control" name="course_duration" />
							<span class="error"></span>
						</div>
						<div class="col-md-3">
							<select type="text" class="form-control" name="course_duration_years_month_day">
								<option>Years</option>
								<option>Year</option>
								<option>Months</option>
								<option>Month</option>
								<option>Days</option>
								<option>Day</option>
							</select>
							<span class="error"></span>
						</div>
					</div>
					<div class="form-group">
						<label class="col-md-3 control-label"><?= translate('course_author') ?></label>
						<div class="col-md-6">
							<input type="text" class="form-control" name="subject_author" />
						</div>
					</div>
					<div class="form-group">
						<label class="col-md-3 control-label"><?= translate('course_type') ?> <span class="required">*</span></label>
						<div class="col-md-6 mb-md">
							<?php
							$subjectArray = array(
								'Theory' => 'Theory',
								'Practical' => 'Practical',

							);
							echo form_dropdown("subject_type", $subjectArray, set_value("subject_type"), "class='form-control populate' data-plugin-selectTwo data-width='100%'
							data-minimum-results-for-search='Infinity' ");
							?>
							<span class="error"></span>
						</div>
					</div>
					<footer class="panel-footer">
						<div class="row">
							<div class="col-md-offset-3 col-md-2">
								<button type="submit" class="btn btn-default btn-block" data-loading-text="<i class='fas fa-spinner fa-spin'></i> Processing">
									<i class="fas fa-plus-circle"></i> <?= translate('save') ?>
								</button>
							</div>
						</div>
					</footer>
					<?php echo form_close(); ?>
				</div>
			<?php endif; ?>
		</div>
	</div>
</section>